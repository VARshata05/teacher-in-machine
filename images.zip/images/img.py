import pandas as pd
import os

# 1. Configuration
excel_input = '20Keywords.xlsx' # Your original file
output_file = 'Keywords_With_Embedded_Images.xlsx'
image_folder = '.' # '.' means current folder where images and excel are

# 2. Prepare the Data
# If your input is the CSV from our previous step, use pd.read_csv
df = pd.read_excel(excel_input) 

# 3. Use XlsxWriter to insert images
writer = pd.ExcelWriter(output_file, engine='xlsxwriter')
df.to_excel(writer, sheet_name='Kids Nouns', index=False)

workbook  = writer.book
worksheet = writer.sheets['Kids Nouns']

# Adjust column width and row height so images fit nicely
worksheet.set_column('D:D', 20) # Column D is where images will go

for i, word in enumerate(df['English']):
    # Check for image file (supporting .png or .jpg)
    img_path = ""
    for ext in ['.png', '.jpg', '.jpeg']:
        temp_path = os.path.join(image_folder, f"{word}{ext}")
        if os.path.exists(temp_path):
            img_path = temp_path
            break
    
    if img_path:
        # Set row height (e.g., 100 pixels) to fit the image
        worksheet.set_row(i + 1, 80) 
        
        # Insert image (scaled to fit the cell)
        worksheet.insert_image(i + 1, 3, img_path, {
            'x_scale': 0.15, 
            'y_scale': 0.15, 
            'x_offset': 5, 
            'y_offset': 5,
            'object_position': 1 # Move and size with cells
        })

writer.close()
print(f"Excel file with embedded images created: {output_file}")